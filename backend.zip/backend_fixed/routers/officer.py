from fastapi import APIRouter, HTTPException, Depends, Header
from models import StatusUpdate, OfficerLogin
from services import db_service
from config import settings

router = APIRouter()


# ─── Simple token check (replace with Supabase Auth in production) ───────────

OFFICER_TOKEN = "officer-secret-token"   # ← swap with real JWT in prod

def verify_officer(authorization: str = Header(...)):
    if authorization != f"Bearer {OFFICER_TOKEN}":
        raise HTTPException(status_code=401, detail="Unauthorized.")


# ─── POST /officer/login ──────────────────────────────────────────────────────

@router.post("/login")
def officer_login(payload: OfficerLogin):
    """
    Quick login for hackathon.
    In production: verify against Supabase Auth.
    """
    if payload.email == "officer@civicai.in" and payload.password == "demo1234":
        return {"token": OFFICER_TOKEN, "message": "Login successful."}
    raise HTTPException(status_code=401, detail="Invalid credentials.")


# ─── GET /officer/complaints ──────────────────────────────────────────────────
# Returns the full queue — Person 4 (Dashboard) reads from here.
# Supports ?urgency=High and ?category=Road filters.

@router.get("/complaints", dependencies=[Depends(verify_officer)])
def get_queue(urgency: str = None, category: str = None):
    complaints = db_service.get_all_complaints(urgency=urgency, category=category)
    return {"total": len(complaints), "complaints": complaints}


# ─── PATCH /officer/complaints/{id}/status ───────────────────────────────────
# Officer moves complaint through: Pending → Assigned → In Progress → Resolved
# Person 4's updateStatus() function calls this.

@router.patch("/complaints/{complaint_id}/status", dependencies=[Depends(verify_officer)])
def update_status(complaint_id: str, payload: StatusUpdate):
    complaint = db_service.get_complaint_by_id(complaint_id)
    if not complaint:
        raise HTTPException(status_code=404, detail="Complaint not found.")

    # Update complaints table
    updated = db_service.update_complaint_status(complaint_id, payload.status.value)

    # Log the change in status_updates (powers citizen timeline)
    db_service.insert_status_update(complaint_id, payload.status.value, payload.note)

    return {"success": True, "new_status": payload.status.value}
